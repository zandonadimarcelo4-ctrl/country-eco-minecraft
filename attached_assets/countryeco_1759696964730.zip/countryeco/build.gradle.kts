plugins {
    id("fabric-loom") version "1.14-SNAPSHOT" // versão estável para 1.21.9
    kotlin("jvm") version "1.9.0"
}

repositories {
    mavenCentral()
    maven("https://maven.fabricmc.net/")
}

dependencies {
    minecraft("com.mojang:minecraft:1.21.9")
    mappings("net.fabricmc:yarn:1.21.9+build.1:v2") // Yarn oficial compatível
    modImplementation("net.fabricmc:fabric-loader:1.21.9")
    modImplementation("net.fabricmc.fabric-api:fabric-api:1.21.9+build.1")
    implementation(kotlin("stdlib"))
}
