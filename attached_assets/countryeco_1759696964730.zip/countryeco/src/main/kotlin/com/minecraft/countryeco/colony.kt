package com.mycountrymod.country

import net.minecraft.util.math.BlockPos
import java.util.*

data class Colony(
    val name: String,
    val parentCountryLeader: UUID,
    val pos1: BlockPos,
    val pos2: BlockPos,
    val type: String // exploration or settlement
)
