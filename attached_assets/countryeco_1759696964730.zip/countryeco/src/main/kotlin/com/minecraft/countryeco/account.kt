package com.mycountrymod.utils

import com.google.gson.Gson
import com.mycountrymod.country.Country
import java.io.File
import java.io.FileReader
import java.io.FileWriter

object JsonStorage {
    private val gson = Gson()

    fun saveCountry(file: File, country: Country) {
        FileWriter(file).use { gson.toJson(country, it) }
    }

    fun loadCountry(file: File): Country? {
        return try {
            FileReader(file).use {
                gson.fromJson(it, Country::class.java)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
