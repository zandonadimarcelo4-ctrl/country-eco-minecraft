package com.mycountrymod.events

import com.mycountrymod.MyCountryMod
import net.fabricmc.fabric.api.event.player.AttackEntityCallback
import net.minecraft.entity.player.PlayerEntity
import net.minecraft.server.network.ServerPlayerEntity
import net.minecraft.util.ActionResult

object PvPTakeoverListener : AttackEntityCallback {
    override fun interact(player: PlayerEntity, target: PlayerEntity, hand: net.minecraft.util.Hand): ActionResult {
        if (player !is ServerPlayerEntity || target !is ServerPlayerEntity) return ActionResult.PASS

        val killer = player
        val victim = target

        MyCountryMod.countries.values.forEach { country ->
            if (country.leader == victim.uuid && country.isInside(victim.blockPos)) {
                // Transfer leadership to killer
                country.leader = killer.uuid
                country.addCitizen(killer)
                // Save JSON
                val file = java.io.File(MyCountryMod.storageDir, "${country.name}.json")
                com.mycountrymod.utils.JsonStorage.saveCountry(file, country)
                killer.sendMessage(net.minecraft.text.Text.literal("You captured ${country.name}! You are now the leader."), false)
                victim.sendMessage(net.minecraft.text.Text.literal("You were defeated in ${country.name}."), false)
            }
        }

        return ActionResult.PASS
    }
}
