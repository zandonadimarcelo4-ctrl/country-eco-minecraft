package com.mycountrymod.country

import net.minecraft.server.network.ServerPlayerEntity
import net.minecraft.util.math.BlockPos
import java.util.*

data class Country(
    val name: String,
    val governmentType: String,
    var leader: UUID,
    val pos1: BlockPos,
    val pos2: BlockPos
) {
    val citizens = mutableSetOf<UUID>(leader)
    val residents = mutableSetOf<UUID>()
    val visitors = mutableSetOf<UUID>()

    fun isInside(pos: BlockPos): Boolean {
        return pos.x in pos1.x..pos2.x &&
                pos.y in pos1.y..pos2.y &&
                pos.z in pos1.z..pos2.z
    }

    fun addCitizen(player: ServerPlayerEntity) {
        citizens.add(player.uuid)
        residents.remove(player.uuid)
        visitors.remove(player.uuid)
    }

    fun addResident(player: ServerPlayerEntity) {
        residents.add(player.uuid)
        visitors.remove(player.uuid)
    }

    fun addVisitor(player: ServerPlayerEntity) {
        visitors.add(player.uuid)
    }

    fun isLeader(player: ServerPlayerEntity): Boolean = leader == player.uuid
}
