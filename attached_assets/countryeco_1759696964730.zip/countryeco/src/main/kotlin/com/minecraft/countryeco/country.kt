package com.mycountrymod

import com.mycountrymod.events.PvPTakeoverListener
import com.mycountrymod.country.Country
import com.mycountrymod.utils.JsonStorage
import net.fabricmc.api.ModInitializer
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback
import net.fabricmc.fabric.api.event.player.AttackEntityCallback
import net.minecraft.server.command.CommandManager
import net.minecraft.text.Text
import java.io.File
import java.util.*

object MyCountryMod : ModInitializer {
    val countries = mutableMapOf<String, Country>()
    lateinit var storageDir: File

    override fun onInitialize() {
        println("[MyCountryMod] Initialized")

        // Directory to save countries
        storageDir = File("countries")
        if (!storageDir.exists()) storageDir.mkdirs()

        // Load countries
        storageDir.listFiles()?.forEach {
            val country = JsonStorage.loadCountry(it)
            if (country != null) countries[country.name] = country
        }

        // Register commands
        CommandRegistrationCallback.EVENT.register { dispatcher, _, _ ->
            dispatcher.register(
                CommandManager.literal("countrycreate")
                    .then(
                        CommandManager.argument("name", net.minecraft.command.argument.StringArgumentType.string())
                            .then(
                                CommandManager.argument("gov", net.minecraft.command.argument.StringArgumentType.string())
                                    .executes { ctx ->
                                        val player = ctx.source.playerOrThrow
                                        val name = net.minecraft.command.argument.StringArgumentType.getString(ctx, "name")
                                        val gov = net.minecraft.command.argument.StringArgumentType.getString(ctx, "gov")

                                        if (countries.containsKey(name)) {
                                            ctx.source.sendFeedback(Text.literal("Country $name already exists!"), false)
                                            return@executes 0
                                        }

                                        val country = Country(name, gov, player.uuid, player.blockPos, player.blockPos)
                                        countries[name] = country
                                        JsonStorage.saveCountry(File(storageDir, "$name.json"), country)

                                        ctx.source.sendFeedback(Text.literal("Country $name created with government $gov!"), false)
                                        1
                                    }
                            )
                    )
            )
        }

        // Register PvP listener
        AttackEntityCallback.EVENT.register(PvPTakeoverListener)
    }
}
